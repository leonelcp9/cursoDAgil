/*****************************************/
/* Capa Presentación: Equipo5            */
/* Autor: Vásquez Tejada Victor Antonio  */
/* 03/06/2021                            */
/*****************************************/

package cursoDAgil.managedBean.ventas;


import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

import java.util.List;


import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import cursoDAgil.bd.domain.Cliente;
import cursoDAgil.bd.domain.DetalleVentas;
import cursoDAgil.bd.domain.Ganancias;
import cursoDAgil.bd.domain.Productos;
import cursoDAgil.bd.domain.Ventas;
import cursoDAgil.managedBean.ganancias.Ganancias2Bean;
import cursoDAgil.managedBean.productos.Productos2Bean;
import cursoDAgil.service.cliente.ClienteService;
import cursoDAgil.service.detalleVentas.DetalleVentasService;
import cursoDAgil.service.ganancias.GananciasService;
import cursoDAgil.service.productos.ProductoService;
import cursoDAgil.service.ventas.VentasService;

@Named
@ViewScoped
public class VentasBean implements Serializable {

	private static final long serialVersionUID = 6472377493921731094L;
	@Inject
	VentasService ventasService;
	@Inject
	ClienteService clienteService;
	@Inject
	DetalleVentasService detalleVentasService;
	@Inject
	ProductoService productoService;
	
	@Inject
	Productos2Bean productos2Bean;
	@Inject
	Ganancias2Bean ganancias2Bean;
	@Inject
	GananciasService gananciasService;
	
	private Ventas selectedVenta;
	private List<Ventas> listaVentas;
	public Ventas venta;
	private List<DetalleVentas> listaDetalleVentas;
	private DetalleVentas detalleVenta;  
	
	private List<Cliente> listaCliente;
	private List<Productos> listaProductos;

	@PostConstruct
	public void init() {
		if (listaCliente == null)
			listaCliente = new ArrayList<Cliente>();
		if (listaDetalleVentas == null)
			listaDetalleVentas = new ArrayList<DetalleVentas>();
		if (detalleVenta == null) {
			detalleVenta = new DetalleVentas();
		}
		if (listaVentas == null)
			listaVentas = new ArrayList<Ventas>();
		if (venta == null) {
			venta = new Ventas();
			venta.setDetalleVentas(listaDetalleVentas);
			venta.setTotalVenta((double) 0);
		}
		// se invoca el metodo del servicio para obtener 

		setlistaVentas(ventasService.obtenerVentas());
		setlistaClientes(clienteService.obtenerClientes());
		setlistaProductos(productoService.obtenerProductos());

	}
	// metodo que registra nuevo marca
	public void nuevaVenta() {
		// invocar al servicio
		ventasService.nuevaVenta(getVenta());
		// limpia los valores del objeto
		setVenta(new Ventas());
		// se actualiza los valores de la tabla
		setlistaVentas(ventasService.obtenerVentas());
		setlistaClientes(clienteService.obtenerClientes());
		setlistaProductos(productoService.obtenerProductos());
		// setlistaMarcas(marcaService.findAllMarcass());
		getlistaVentas();
		productos2Bean.setlistaProductos(productoService.obtenerProductos());
		ganancias2Bean.setListaGanancias(gananciasService.obtenerGanancias());
		FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Registro exitoso!"));
	}
	
	public void addCar() { 
		if((detalleVenta.getProductos().getCantidad()-detalleVenta.getCantidad())<0){
			FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Lo sentimos. No hay suficientes en existencia"));
			return;
		}
		detalleVenta.setProductoId(detalleVenta.getProductos().getIdProducto());
		venta.setTotalVenta(venta.getTotalVenta()+detalleVenta.getProductos().getPrecioVta()*detalleVenta.getCantidad());
		listaDetalleVentas.add(detalleVenta);
		setDetalleVenta(new DetalleVentas());
		System.out.println("Agregado");
	}
	public void registrarCar() {
		if(listaDetalleVentas.size()==0) { 
			FacesContext.getCurrentInstance().addMessage("null", new FacesMessage("Debe seleccionar un cliente, producto y cantidad!"));
			return;
		} 
		venta.setDetalleVentas(listaDetalleVentas);
		venta.setGanancia(new Ganancias());
		venta.setClienteId(getVenta().getCliente().getId());
		venta.setFecha(LocalDate.now().toString()); 
		nuevaVenta();
		cleanCar();
		System.out.println("Venta registrada");
	}
	public void cleanCar() {
		venta = new Ventas();
		venta.setTotalVenta((double) 0);
		setDetalleVenta(new DetalleVentas());
		listaDetalleVentas = new ArrayList<DetalleVentas>();
		
	}
	public void changeVenta(){
		System.out.println(" Detalle de venta obtenido correctamente");
	    for(DetalleVentas dv: selectedVenta.getDetalleVentas()) {
	    	dv.setProductos(productoService.obtenerProductoPorId(dv.getProductoId())); 
	    }
	    
	}
 
	// setters y getters
	public DetalleVentas getDetalleVenta() {
		return detalleVenta;
	}
	public void setDetalleVenta(DetalleVentas dv) {
		this.detalleVenta = dv;
	}
	public Ventas getVenta() {
		return venta;
	}

	public void setVenta(Ventas venta) {
		this.venta = venta;
	}

	public List<Ventas> getlistaVentas() {
		return listaVentas;
	}

	public void setlistaVentas(List<Ventas> listaVentas) {
		this.listaVentas = listaVentas;
	}
	public void setlistaClientes(List<Cliente> listaC) {
		this.listaCliente = listaC;
	}
	public List<Cliente> getlistaClientes() {
		return listaCliente;
	}
	public List<Productos> getlistaProductos(){
		return listaProductos;
	}
	public void setlistaProductos(List<Productos> lp) {
		this.listaProductos = lp;
	}
	public List<DetalleVentas> getListaDetalleVentas(){
		return listaDetalleVentas;
	}
	public Ventas getSelectedVenta() {
		return selectedVenta;
	}
	public void setSelectedVenta(Ventas v) {
		this.selectedVenta = v;
	}
}