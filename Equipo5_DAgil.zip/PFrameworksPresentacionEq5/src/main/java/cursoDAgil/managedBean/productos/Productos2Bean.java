/*****************************************/
/* Proyecto presentacion Equipo5         */
/* Autor: Hernández Santos Marco Antonio */
/* 29/05/2021                            */
/*****************************************/

package cursoDAgil.managedBean.productos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.CellEditEvent;
import org.primefaces.event.RowEditEvent;

import cursoDAgil.bd.domain.Productos;
import cursoDAgil.managedBean.ventas.VentasBean;
import cursoDAgil.service.productos.ProductoService;

@Named
@ViewScoped
public class Productos2Bean implements Serializable {
	private static final long serialVersionUID = 6472377493921731094L;
	@Inject
	ProductoService productoService;
	@Inject
	VentasBean ventasBean;
	private List<Productos> listaProductos;
	private Productos producto;
	

	@PostConstruct
	public void init() {
		if (listaProductos == null)
			listaProductos = new ArrayList<Productos>();
		if (producto == null) {
			producto = new Productos();
			producto.setMarca(null);
		}
		// se invoca el metodo del servicio para obtener los productos

		setlistaProductos(productoService.obtenerProductos());
		// setlistaMarcas(marcaService.findAllMarcass());
	}

	// metodo que registra nuevo producto
	public void registrar() {
		// invocar al servicio
		productoService.nuevoProducto(getProducto());
		// limpia los valores del objeto
		setProducto(new Productos());
		// se actualiza los valores de la tabla
		setlistaProductos(productoService.obtenerProductos());
		// setlistaMarcas(marcaService.findAllMarcass());
		getlistaProductos();
		ventasBean.setlistaProductos(productoService.obtenerProductos());
		FacesContext.getCurrentInstance().addMessage("aqui falla null", new	FacesMessage("Registro exitoso!"));
	
	}

	public void onRowEdit(RowEditEvent event) {
		Productos prod = ((Productos) event.getObject());

		System.out.println("Verificando edición");
		if(prod.getNombre()=="" || prod.getPrecio()==0 || prod.getPrecioVta()==0 || prod.getCantidad()==0){
			FacesMessage msg = new FacesMessage("¡Falló la edición!, ha dejado algun campo vacío. Por favor llene "
					+ "todos los campos o al reiniciar el sistema su dirección aparecerá como la última edición "
					+ "guardada.", prod.getIdProducto().toString());
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}else{
			prod.setMarca(producto.getMarca());
			productoService.modificarProductoPorId(prod);
			ventasBean.setlistaProductos(productoService.obtenerProductos());
			FacesMessage msg = new FacesMessage("Producto editado", prod.getIdProducto().toString());
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
	}

	public void onRowCancel(RowEditEvent event) {
		FacesMessage msg = new FacesMessage("Edición cancelada",

				((Productos) event.getObject()).getIdProducto().toString());

		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void onCellEdit(CellEditEvent event) {
		Object oldValue = event.getOldValue();
		Object newValue = event.getNewValue();
		System.out.println("verifica: " + newValue);
		if (newValue != null && !newValue.equals(oldValue)) {
			FacesMessage msg = new

			FacesMessage(FacesMessage.SEVERITY_INFO, "Producto modificado", "Antes: " + oldValue + ", Ahora: " +

					newValue);

			FacesContext.getCurrentInstance().addMessage(null, msg);
			
		}
	}
	
	//nueva funcion para eliminar 
	public void eliminar(){
		listaProductos = getlistaProductos();
		boolean bandera=false;
		System.out.println("entroaqui");
		//	listaMarcas = marcaService.obtenerMarcas();
		for(Productos p: listaProductos){
//			System.out.printf("productos: " + p.getNombreMarca() + " valor: " + p.getSelected() + "\n" );

			if(p.getSelected()){
				productoService.eliminarProductoPorId(p.getIdProducto());
				setlistaProductos(productoService.obtenerProductos());
				bandera=true;
			}
		}
		if(bandera){
			getlistaProductos();
			ventasBean.setlistaProductos(productoService.obtenerProductos());
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Producto eliminado"));
		}
		
	}
	

	// setters y getters
	public Productos getProducto() {
		return producto;
	}

	public void setProducto(Productos producto) {
		this.producto = producto;
	}

	public List<Productos> getlistaProductos() {
		return listaProductos;
	}
	


	public void setlistaProductos(List<Productos> listaProductos) {
		this.listaProductos = listaProductos;
	}
}