/*****************************************/
/* Proyecto presentacion Equipo5         */
/* Autor: Hernández Santos Marco Antonio */
/* 29/05/2021                            */
/*****************************************/

package cursoDAgil.managedBean.marcas;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.CellEditEvent;
import org.primefaces.event.RowEditEvent;

import cursoDAgil.bd.domain.Marcas;
import cursoDAgil.managedBean.productos.Productos2Bean;
import cursoDAgil.service.marcas.MarcasService;
import cursoDAgil.service.productos.ProductoService;

@Named
@ViewScoped
public class Marcas2Bean implements Serializable {

	private static final long serialVersionUID = 6472377493921731094L;
	@Inject
	MarcasService marcaService;
	@Inject
	ProductoService productoService;
	@Inject
	Productos2Bean productoBean;
	private List<Marcas> listaMarcas;
	private Marcas marca;
	

	@PostConstruct
	public void init() {
		if (listaMarcas == null)
			listaMarcas = new ArrayList<Marcas>();
		if (marca == null) {
			marca = new Marcas();
		//	marca.setDireccion(null);
		}
		// se invoca el metodo del servicio para obtener los marcas

		setlistaMarcas(marcaService.obtenerMarcas());
		// setlistaMarcas(marcaService.findAllMarcass());
	}

	public void actualizar(){
	setMarcas(new Marcas());
	// se actualiza los valores de la tabla
	setlistaMarcas(marcaService.obtenerMarcas());
	// setlistaMarcas(marcaService.findAllMarcass());
	getlistaMarcas();
	}
	
	// metodo que registra nuevo marca
	public void registrar() {
		// invocar al servicio
		marcaService.nuevaMarca(getMarcas());
		// limpia los valores del objeto
		setMarcas(new Marcas());
		// se actualiza los valores de la tabla
		setlistaMarcas(marcaService.obtenerMarcas());
		// setlistaMarcas(marcaService.findAllMarcass());
		getlistaMarcas();
		FacesContext.getCurrentInstance().addMessage("aqui falla null", new

		FacesMessage("Registro exitoso!"));

	}

	public void onRowEdit(RowEditEvent event) {
		Marcas mar = ((Marcas) event.getObject());
		
		System.out.println("Verificando edición");
		if(mar.getNombreMarca()==""){
			FacesMessage msg = new FacesMessage("¡Falló la edición!, ha dejado algun campo vacío. Por favor llene "
					+ "todos los campos o al reiniciar el sistema su dirección aparecerá como la última edición "
					+ "guardada.", mar.getIdMarca().toString());
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}else{
			marcaService.modificarMarcaPorId(mar);
			FacesMessage msg = new FacesMessage("Marca editada", mar.getIdMarca().toString());
			productoBean.setlistaProductos(productoService.obtenerProductos());
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
	}

	public void onRowCancel(RowEditEvent event) {
		FacesMessage msg = new FacesMessage("Edición cancelada", ((Marcas) event.getObject()).getIdMarca().toString());
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	
	
	public void onCellEdit(CellEditEvent event) {
		Object oldValue = event.getOldValue();
		Object newValue = event.getNewValue();
		System.out.println("verifica: " + newValue);
		if (newValue != null && !newValue.equals(oldValue)) {
			FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Marca modificada", "Antes: " + oldValue + ", Ahora: " + newValue);
			FacesContext.getCurrentInstance().addMessage(null, msg);
			getlistaMarcas();
			productoBean.setlistaProductos(productoService.obtenerProductos());
		}
	}
	
	//nueva funcion para eliminar 
	public void eliminar(){
		listaMarcas = getlistaMarcas();
		boolean bandera=false;
		//	listaMarcas = marcaService.obtenerMarcas();
		for(Marcas p: listaMarcas){
//			System.out.printf("productos: " + p.getNombreMarca() + " valor: " + p.getSelected() + "\n" );

			if(p.getSelected()){
				marcaService.eliminarMarcaPorId(p.getIdMarca());
				setlistaMarcas(marcaService.obtenerMarcas());
				bandera=true;
			}
		}
		if(bandera){
			getlistaMarcas();
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Marca eliminada"));
			productoBean.setlistaProductos(productoService.obtenerProductos());
		}
		
	}
	

	// setters y getters
	public Marcas getMarcas() {
		return marca;
	}

	public void setMarcas(Marcas marca) {
		this.marca = marca;
	}

	public List<Marcas> getlistaMarcas() {
		return listaMarcas;
	}

	public void setlistaMarcas(List<Marcas> listaMarcas) {
		this.listaMarcas = listaMarcas;
	}
}