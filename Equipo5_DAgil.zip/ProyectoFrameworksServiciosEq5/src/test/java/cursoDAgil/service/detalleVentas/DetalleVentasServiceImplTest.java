package cursoDAgil.service.detalleVentas;


import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.DetalleVentas;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/applicationContext.xml"})
public class DetalleVentasServiceImplTest {
	
	@Inject
	DetalleVentasService detalleVentasDao;
	
	@Ignore
	public void consultarDetalleVentaPorIdVenta(){
		Map<String, Integer> mapDetalleVentas = new HashMap<>();
		mapDetalleVentas.put("ventaId", 22);
		System.out.println("\nDetalle de venta por idVenta");
		try{
			List<DetalleVentas> lista = detalleVentasDao.obtenerDetallesVentasPorVenta(22);
			int reg = lista.size();
			assertEquals(lista.size(),reg);
			System.out.println("\n\n\nRegistro en la tabla: " + reg + " detalle ventas");	
		} catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Ignore
	public void crearDetalleVenta(){
		DetalleVentas detalleVenta = new DetalleVentas();
		System.out.println("\n\nCrear Detalle Venta\n");
		try{
			detalleVenta.setCantidad(1);
			detalleVenta.setVentaId(1);
			detalleVenta.setProductoId(1);
			detalleVentasDao.nuevoDetalleVentas(detalleVenta);
		} catch(Exception e){
			System.out.println("Error" + e);
		}
	}	
	
	@Test
	public void pruebaConsultarTodo(){
		int reg;
		System.out.println("\n\nTest consultar todos los detalles ventas\n");
		try{
			List<DetalleVentas> lista = detalleVentasDao.obtenerDetallesVentas();
			reg = lista.size();
			assertEquals(lista.size(), reg);
			System.out.println("\nRegistro en la tabla: " + reg + " detalles ventas");
		}catch(Exception ex){
			System.out.println("error" + ex);
		}
	}
	
}