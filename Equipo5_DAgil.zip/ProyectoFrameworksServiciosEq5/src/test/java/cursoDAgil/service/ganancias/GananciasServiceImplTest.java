package cursoDAgil.service.ganancias;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Ganancias;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"/applicationContext.xml"})
public class GananciasServiceImplTest {
	@Inject
	GananciasService gananciasService;
	
	@Test
	public void consultarTodo(){
		System.out.println("Test obtener todas las Ganancias:\n");
		try{
			List<Ganancias> lista = gananciasService.obtenerGanancias();
			int reg=lista.size();
			assertEquals(lista.size(), reg);
		} catch(Exception e){
			System.out.println("Error: " + e);
		}
	}

	@Ignore
	public void consultarPorFecha(){
		Map<String,String> mapGanancias = new HashMap<String, String>();
		mapGanancias.put("fecha", "2021-04-20");
		System.out.println("\nTest obtener Ganancias por fecha:\n");
		try{
			List<Ganancias> lista = gananciasService.obtenerGananciaPorFecha(mapGanancias);
			int reg=lista.size();
			assertEquals(lista.size(), reg);
		} catch(Exception e){
			System.out.println("Error: " + e);
		}
	}
	
	@Ignore
	public void crearGanancia(){
		Ganancias ganancia = new Ganancias();
		System.out.println("\n\nTest crear ganancia");
		try{
			ganancia.setFecha("13-05-20");
			ganancia.setTotalGanancia(288.00);
			ganancia.setVentaId(21);
			gananciasService.nuevaGanancia(ganancia);
		}catch(Exception ex){
			System.out.println("error" + ex);
		}
	}
}