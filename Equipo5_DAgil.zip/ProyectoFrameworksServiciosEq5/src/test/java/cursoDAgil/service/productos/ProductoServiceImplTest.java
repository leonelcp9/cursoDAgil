package cursoDAgil.service.productos;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Productos;
import cursoDAgil.service.productos.ProductoService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"/applicationContext.xml"})

public class ProductoServiceImplTest {
	
	@Inject
	ProductoService productoService;
	
	@Test
	public void consultarTodo(){
		System.out.println("Test obtener todos los Productos con marca:\n");
		try{
			List<Productos> lista = productoService.obtenerProductos();
			int reg = lista.size();
			assertEquals(lista.size(),reg);
		} catch(Exception e){
			System.out.println("Error: " + e);
		}
	}
	
	@Test	
	public void pruebaConsultarTodoSinMarca(){
		int reg;
		System.out.println("\n\nTest consultar todos los productos sin marca\n");
		try{
			List<Productos> lista = productoService.obtenerProductos_SinMarca();
			reg = lista.size();
			assertEquals(lista.size(), reg);
			System.out.println("\n\nRegistro en la tabla: " + reg + " productos");
		}catch(Exception ex){
			System.out.println("error" + ex);
		}
	}
	
	@Ignore
	public void nuevoProducto(){
		Productos producto = new Productos();
		System.out.println("\n\nTest nuevo registro de Producto\n");
		try{
			producto.setNombre("Tenis");
			producto.setPrecio(2100);
			producto.setPrecioVta(2500);
			producto.setCantidad(6);
			producto.setMarcaId(5);
			productoService.nuevoProducto(producto);
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Ignore		
	public void modificarProducto(){
		Productos producto = new Productos();
		System.out.println("\n\nTest modificar Producto\n");
		try{
			producto.setIdProducto(19);
			producto.setNombre("Sandalias");
			producto.setPrecio(300);
			producto.setPrecioVta(450);
			producto.setCantidad(20);
			producto.setMarcaId(3);
			productoService.modificarProductoPorId(producto);
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Ignore		
	public void consultarProductoPorId(){
		Productos producto = new Productos();
		Map<String, Integer> mapProducto = new HashMap<>();
		mapProducto.put("idProducto", 29);
		System.out.println("\n\nTest consultar producto por id con marca\n");
		try{
			producto = productoService.obtenerProductoPorId(mapProducto);
			assertNotNull(producto);
			System.out.println("idProducto: " + producto.getIdProducto());
			System.out.println("Producto: " + producto.getNombre());
			System.out.println("Precio: " + producto.getPrecio());
			System.out.println("Nombre: " + producto.getPrecioVta());
			System.out.println("Cantidad: " + producto.getCantidad());
			System.out.println("Marca: " + producto.getMarca().getNombreMarca() + "\n");
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Ignore		
	public void consultarProductoPorIdSinMarca(){
		Productos producto = new Productos();
		Map<String, Integer> mapProducto = new HashMap<>();
		mapProducto.put("idProducto", 29);
		System.out.println("\n\nTest consultar producto por id sin marca\n");
		try{
			producto = productoService.obtenerProductoPorId_SinMarca(mapProducto);
			assertNotNull(producto);
			System.out.println("idProducto: " + producto.getIdProducto());
			System.out.println("Producto: " + producto.getNombre());
			System.out.println("Precio: " + producto.getPrecio());
			System.out.println("Nombre: " + producto.getPrecioVta());
			System.out.println("Cantidad: " + producto.getCantidad());
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Ignore
	public void eliminarProducto(){
		Productos producto = new Productos();
		Map<String, Integer> mapProducto = new HashMap<>();
		mapProducto.put("idProducto", 24);
		System.out.println("\n\nTest eliminar de Producto\n");
		try{
			productoService.eliminarProductoPorId(mapProducto);
			assertNotNull(producto);
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
}
