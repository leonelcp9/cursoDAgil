package cursoDAgil.service.marcas;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Marcas;
import cursoDAgil.service.marcas.MarcasService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/applicationContext.xml"})
public class MarcasServiceImplTest {
	@Inject
	MarcasService marcasService;
		
	@Test
	public void pruebaConsultarTodo(){
		System.out.println("\n\nTest consular todas las marcas");
		try{
			List<Marcas> lista = marcasService.obtenerMarcas();
			int reg = lista.size();
			assertEquals(lista.size(),reg);
			System.out.println("\n\n\nRegistro en la tabla: " + reg + " marcas");		
		}catch(Exception ex){
			System.out.println("error" + ex);
		}
	}
	
	@Ignore
	public void consultarMarcaPorId(){
		Marcas marca = new Marcas();
		Map<String, Integer> mapMarca = new HashMap<>();
		mapMarca.put("idMarca", 1);
		System.out.println("\n\nTest consultar marca por id\n");
		try{
			marca = marcasService.obtenerMarcaPorId(mapMarca);
			assertNotNull(marca);
			System.out.println("id: " + marca.getIdMarca());
			System.out.println("Nombre: " + marca.getNombreMarca());
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	
	@Ignore
	public void nuevaMarca(){
		Marcas marca = new Marcas();
		System.out.println("\n\nTest nuevo registro de marca\n");
		try{
			marca.setNombreMarca("Converse");
			marcasService.nuevaMarca(marca);
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Ignore	
	public void modificarMarca(){
		Marcas marca = new Marcas();
		System.out.println("\n\nTest modificar marca\n");
		try{
			marca.setIdMarca(3);
			marca.setNombreMarca("Puma");
			marcasService.modificarMarcaPorId(marca);
			assertNotNull(marca);
			System.out.println("Datos Marca actualizados");

		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Ignore		
	public void eliminarMarca(){
		Marcas marca = new Marcas();
		Map<String, Integer> mapMarca = new HashMap<>();
		mapMarca.put("idMarca", 11);
		System.out.println("\n\nTest eliminar marca\n");
		try{
			marcasService.eliminarMarcaPorId(mapMarca);
			assertNotNull(marca);
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
}