package cursoDAgil.service.cliente;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Cliente;
import cursoDAgil.service.cliente.ClienteService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/applicationContext.xml"})
public class ClienteServiceImplTest {
	@Inject
	ClienteService clienteService;
		
	@Test
	public void pruebaConsultarTodo(){
		System.out.println("\n\nTest consular todos los clientes con direccion");
		try{
			List<Cliente> lista = clienteService.obtenerClientes();
			int reg = lista.size();
			assertEquals(lista.size(),reg);
			System.out.println("\n\n\nRegistro en la tabla: " + reg + " clientes");		
		}catch(Exception ex){
			System.out.println("error" + ex);
		}
	}
	
	@Test
	public void pruebaConsultarTodoSinDireccion(){
		System.out.println("\n\nTest consular todos los clientes sin direccion");
		try{
			List<Cliente> lista = clienteService.obtenerClientes_SinDireccion();
			int reg = lista.size();
			assertEquals(lista.size(),reg);
			System.out.println("\n\n\nRegistro en la tabla: " + reg + " clientes");		
		}catch(Exception ex){
			System.out.println("error" + ex);
		}
	}
	
	@Ignore
	public void consultarClientePorId(){
		Cliente cliente = new Cliente();
		System.out.println("\n\nTest consultar cliente por id con direccion\n");
		try{
			cliente = clienteService.obtenerClientePorId(1);
			assertNotNull(cliente);
			System.out.println("id: " + cliente.getId());
			System.out.println("Nombre: " + cliente.getNombre());
			System.out.println("Apellido: " + cliente.getApellido());
			System.out.println("Email: " + cliente.getEmail());
			System.out.println("Sexo: " + cliente.getSexo());
			System.out.println("Direccion: "+ cliente.getDireccion().getCalle() + " #" + cliente.getDireccion().getNumero() + ", " +cliente.getDireccion().getCiudad());
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}

	@Ignore
	public void consultarClientePorIdSinDireccion(){
		Cliente cliente = new Cliente();
		Map<String, Integer> mapCliente = new HashMap<>();
		mapCliente.put("id", 1);
		System.out.println("\n\nTest consultar cliente por id sin direccion\n");
		try{
			cliente = clienteService.obtenerClientePorId_SinDireccion(mapCliente);
			assertNotNull(cliente);
			System.out.println("id: " + cliente.getId());
			System.out.println("Nombre: " + cliente.getNombre());
			System.out.println("Apellido: " + cliente.getApellido());
			System.out.println("Email: " + cliente.getEmail());
			System.out.println("Sexo: " + cliente.getSexo());
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Ignore
	public void nuevoCliente(){
		Cliente cliente = new Cliente();
		System.out.println("\n\nTest nuevo registro de cliente\n");
		try{
			cliente.setNombre("Marco");
			cliente.setApellido("HS");
			cliente.setEmail("hs@gmail.com");
			cliente.setSexo("M");
			cliente.setIddireccion(1);
			clienteService.nuevoCliente(cliente);
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Ignore	
	public void modificarCliente(){
		Cliente cliente = new Cliente();
		System.out.println("\n\nTest modificar Cliente\n");
		try{
			cliente.setId(12);
			cliente.setNombre("Erika");
			cliente.setApellido("Martinez");
			cliente.setEmail("mtz_erika@hotmail.com");
			cliente.setSexo("F");
			cliente.setIddireccion(5);
			clienteService.modificarClientePorId(cliente);
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Ignore		
	public void eliminarCliente(){
		Cliente cliente = new Cliente();
		Map<String, Integer> mapCliente = new HashMap<>();
		mapCliente.put("id", 14);
		System.out.println("\n\nTest eliminar cliente\n");
		try{
			clienteService.eliminarClientePorId(mapCliente);
			assertNotNull(cliente);
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
}
