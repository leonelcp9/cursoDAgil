package cursoDAgil.service.cliente;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import cursoDAgil.bd.domain.Cliente;
import cursoDAgil.dao.cliente.ClienteDao;


@Named
public class ClienteServiceImpl implements ClienteService, Serializable {
	
	private static final long serialVersionUID = -3067887428564604517L;

	@Inject
	ClienteDao clienteDao;
	
	@Override
	public List<Cliente> obtenerClientes(){
		return clienteDao.obtenerClientes();
	}
	
	@Override
	public List<Cliente> obtenerClientes_SinDireccion(){
		return clienteDao.obtenerClientes_SinDireccion();
	}
	
	@Override
	public Integer nuevoCliente(Cliente cliente) {
		return clienteDao.nuevoCliente(cliente);
	}

	@Override
	public Cliente obtenerClientePorId(Integer idCliente) {
		return clienteDao.obtenerClientePorId(idCliente);
	}
	
	@Override
	public Cliente obtenerClientePorId_SinDireccion(Map<String, Integer> mapCliente) {
		return clienteDao.obtenerClientePorId_SinDireccion(mapCliente);
	}

	@Override
	public Integer modificarClientePorId(Cliente cliente){
		return clienteDao.modificarClientePorId(cliente);
	}
	
	@Override
	public Integer eliminarClientePorId(Map<String, Integer> mapCliente){
		return clienteDao.eliminarClientePorId(mapCliente);
	}
	
	@Override
	public Integer eliminarClientePorId(Integer idCliente){
		return clienteDao.eliminarClientePorId(idCliente);
	}
}
