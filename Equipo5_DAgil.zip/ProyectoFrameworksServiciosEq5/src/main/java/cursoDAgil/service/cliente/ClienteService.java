package cursoDAgil.service.cliente;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Cliente;

public interface ClienteService {
	List<Cliente> obtenerClientes();
	Integer nuevoCliente(Cliente cliente);
	Integer modificarClientePorId(Cliente cliente);
	Integer eliminarClientePorId(Map<String, Integer> mapCliente);
	Cliente obtenerClientePorId(Integer idCliente);
	Integer eliminarClientePorId(Integer idCliente);
	List<Cliente> obtenerClientes_SinDireccion();
	Cliente obtenerClientePorId_SinDireccion(Map<String, Integer> mapCliente);
}
