package cursoDAgil.service.productos;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Productos;

public interface ProductoService {
	List<Productos> obtenerProductos();
	Integer nuevoProducto(Productos producto);
	Productos obtenerProductoPorId(Map<String, Integer> mapProductos);
	Integer modificarProductoPorId(Productos producto);
	Integer eliminarProductoPorId(Map<String, Integer> mapProductos);
	
	List<Productos> obtenerProductos_SinMarca();
	Productos obtenerProductoPorId_SinMarca(Map<String, Integer> mapProductos);
	
	Productos obtenerProductoPorId(Integer idProductos);
	Integer eliminarProductoPorId(Integer idProductos);
}
