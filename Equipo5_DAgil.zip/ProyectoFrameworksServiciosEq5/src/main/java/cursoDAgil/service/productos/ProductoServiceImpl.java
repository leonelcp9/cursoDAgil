package cursoDAgil.service.productos;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import cursoDAgil.bd.domain.Productos;
import cursoDAgil.dao.productos.ProductoDao;

@Named
public class ProductoServiceImpl implements ProductoService, Serializable{
	
	private static final long serialVersionUID = -3067887428564604517L;
	
	@Inject
	ProductoDao productoDao;

	public List<Productos> obtenerProductos() {
		return productoDao.obtenerProductos();
	}
	
	public List<Productos> obtenerProductos_SinMarca() {
		return productoDao.obtenerProductos_SinMarca();
	}


	public Integer nuevoProducto(Productos producto) {
		// TODO Auto-generated method stub
		return productoDao.nuevoProducto(producto);
	}

	public Productos obtenerProductoPorId(Map<String, Integer> mapProductos) {
		// TODO Auto-generated method stub
		return productoDao.obtenerProductoPorId(mapProductos);
	}
	
	public Productos obtenerProductoPorId_SinMarca(Map<String, Integer> mapProductos) {
		// TODO Auto-generated method stub
		return productoDao.obtenerProductoPorId_SinMarca(mapProductos);
	}

	public Integer modificarProductoPorId(Productos producto) {
		// TODO Auto-generated method stub
		return productoDao.modificarProductoPorId(producto);
	}

	public Integer eliminarProductoPorId(Map<String, Integer> mapProductos) {
		// TODO Auto-generated method stub
		return productoDao.eliminarProductoPorId(mapProductos);
	}
	
	public Productos obtenerProductoPorId(Integer idProductos) {
		// TODO Auto-generated method stub
		return productoDao.obtenerProductoPorId(idProductos);
	}

	public Integer eliminarProductoPorId(Integer idProductos) {
		// TODO Auto-generated method stub
		return productoDao.eliminarProductoPorId(idProductos);
	}
}
