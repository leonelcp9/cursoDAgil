package cursoDAgil.service.marcas;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import cursoDAgil.bd.domain.Marcas;
import cursoDAgil.dao.marcas.MarcasDao;

@Named
public class MarcasServiceImpl implements MarcasService, Serializable{
	

	private static final long serialVersionUID = -3067887428564604517L;
	
	@Inject
	MarcasDao marcasDao;
	
	@Override
	public List<Marcas> obtenerMarcas(){
		return marcasDao.obtenerMarcas();
	}
	
	@Override
	public Integer nuevaMarca(Marcas marca) {
		return marcasDao.nuevaMarca(marca);
	}

	@Override
	public Marcas obtenerMarcaPorId(Map<String, Integer> mapMarcas) {
		return marcasDao.obtenerMarcaPorId(mapMarcas);
	}
	
	@Override
	public Marcas obtenerMarcaPorId(Integer idMarca) {
		return marcasDao.obtenerMarcaPorId(idMarca);
	}

	@Override
	public Integer modificarMarcaPorId(Marcas marca){
		return marcasDao.modificarMarcaPorId(marca);
	}
	
	@Override
	public Integer eliminarMarcaPorId(Map<String, Integer> mapMarcas){
		return marcasDao.eliminarMarcaPorId(mapMarcas);
	}
	@Override
	public Integer eliminarMarcaPorId(Integer idMarca){
		return marcasDao.eliminarMarcaPorId(idMarca);
	}
}