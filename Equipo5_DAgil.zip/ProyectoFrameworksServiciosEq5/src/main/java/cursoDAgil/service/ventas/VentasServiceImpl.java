package cursoDAgil.service.ventas;


import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;

import cursoDAgil.bd.domain.Ventas;
import cursoDAgil.dao.ventas.VentasDao;

@Named
public class VentasServiceImpl implements VentasService, Serializable{
	
	private static final long serialVersionUID = -3067887428564604517L;
	SqlSession sqlSession;

	@Inject
	VentasDao ventasDao;


	public Integer nuevaVenta(Ventas venta) {
		return ventasDao.nuevaVenta(venta);
	}


	public List<Ventas> obtenerVentasPorIdCliente(Integer idCliente) {
		Map<String, Integer> mapVentas = new HashMap<>();
		mapVentas.put("clienteId", idCliente );
		return ventasDao.obtenerVentasPorIdCliente(mapVentas);
	}


	public List<Ventas> obtenerVentas() {
		return ventasDao.obtenerVentas();
	}
}