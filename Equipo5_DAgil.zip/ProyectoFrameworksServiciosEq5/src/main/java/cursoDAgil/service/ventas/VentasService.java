package cursoDAgil.service.ventas;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Ventas;

public interface VentasService {
	Integer nuevaVenta(Ventas venta);
	List<Ventas> obtenerVentas();
	List<Ventas> obtenerVentasPorIdCliente(Integer idCliente);
}
