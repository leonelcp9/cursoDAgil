package cursoDAgil.service.direccion;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Direccion;

public interface DireccionService {
	List<Direccion> obtenerDirecciones();
	Integer nuevaDireccion(Direccion direccion);
	Direccion obtenerDireccionPorId(Map<String, Integer> mapDirecciones);
	Integer modificarDireccionPorId(Direccion Direccion);
	Integer eliminarDireccionPorId(Map<String, Integer> mapDirecciones);
	Direccion obtenerDireccionPorId(Integer idDireccion);
	Integer eliminarDireccionPorId(Integer idDireccion);
	
}
