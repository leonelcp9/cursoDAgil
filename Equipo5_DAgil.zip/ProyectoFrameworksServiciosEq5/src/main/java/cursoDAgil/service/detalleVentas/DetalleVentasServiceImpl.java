package cursoDAgil.service.detalleVentas;


import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;

import cursoDAgil.bd.domain.DetalleVentas;
import cursoDAgil.dao.detalleVentas.DetalleVentasDao;


@Named
public class DetalleVentasServiceImpl implements DetalleVentasService, Serializable{
	
	private static final long serialVersionUID = -3067887428564604517L;
	SqlSession sqlSession;

	@Inject
	DetalleVentasDao detalleVentasDao;
	
	@Override
	public Integer nuevoDetalleVentas(DetalleVentas detalleVentas) {
		return detalleVentasDao.nuevoDetalleVentas(detalleVentas);
	}
	
	@Override
	public List <DetalleVentas>  obtenerDetallesVentasPorVenta(Integer idDetalleVentas) {
		Map<String, Integer> mapdv = new HashMap<>();
		mapdv.put("ventaId", idDetalleVentas);
		return detalleVentasDao.obtenerDetallesVentasPorVenta(mapdv);
	}
	
	public List <DetalleVentas>  obtenerDetallesVentas() {
		return detalleVentasDao.obtenerDetallesVentas();
	}
}