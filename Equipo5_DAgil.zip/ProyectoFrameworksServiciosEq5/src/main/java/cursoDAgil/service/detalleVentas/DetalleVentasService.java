package cursoDAgil.service.detalleVentas;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.DetalleVentas;

public interface DetalleVentasService {
	Integer nuevoDetalleVentas(DetalleVentas detalleVentas);
	List<DetalleVentas> obtenerDetallesVentasPorVenta(Integer idDetalleVentas);
	List <DetalleVentas> obtenerDetallesVentas();
}