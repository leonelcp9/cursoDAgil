package cursoDAgil.bd.domain;

public class Productos {
	private Integer idProducto;
	private String nombre;
	private double precio;
	private double precioVta;
	private Integer cantidad;
	private Integer marcaId;
	
	private Marcas marca;
	private boolean selected;
	
	public Productos(){
		setMarca(new Marcas());
	}
	public Marcas getMarca() {
		return marca;
	}
	public void setMarca(Marcas marca) {
		this.marca = marca;
	}
	
	
	
	public Integer getIdProducto(){
		return idProducto;
	}

	public void setIdProducto(Integer idProducto){
		this.idProducto= idProducto;
	}

	public String getNombre(){
		return nombre;
	}

	public void setNombre(String nombre){
		this.nombre= nombre;
	}

	public double getPrecio(){
		return precio;
	} 

	public void setPrecio(double precio){
		this.precio= precio;
	}

	public double getPrecioVta(){
		return precioVta;
	}

	public void setPrecioVta (double precioVta){
		this.precioVta= precioVta;
	}

	public Integer getCantidad(){
		return cantidad;
	}

	public void setCantidad(Integer cantidad){
		this.cantidad= cantidad;
	}

	public Integer getMarcaId (){
		return marcaId;
	}

	public void setMarcaId(Integer marcaId){
		this.marcaId= marcaId;
	}
	
	public boolean equals(Object object){
		if(!(object instanceof Productos)){
			return false;
		}
		Productos regProductos = (Productos) object;
		return(this.idProducto == regProductos.idProducto);
	}
	
	public boolean getSelected() {
		return selected;
	}
	public void setSelected(boolean selected) {
		this.selected = selected;
	}
	
	
}
