package cursoDAgil.bd.domain;

public class Marcas {
	private String nombreMarca;
	private Integer idMarca;
	private boolean selected;
	
	public void setNombreMarca(String nombreMarca) {
		this.nombreMarca = nombreMarca;
	}
	public String getNombreMarca() {
		return this.nombreMarca;
	}
	public void setIdMarca(Integer idMarca) {
		this.idMarca = idMarca;
	}
	public Integer getIdMarca() {
		return this.idMarca;
	}
	
	public boolean equals(Object object) {
		if (!(object instanceof Marcas)) {
			return false;
		}
		Marcas regMarcas = (Marcas) object;
		return (this.idMarca == regMarcas.idMarca);
	}
	
	public boolean getSelected() {
		return selected;
	}
	public void setSelected(boolean selected) {
		this.selected = selected;
	}
}
