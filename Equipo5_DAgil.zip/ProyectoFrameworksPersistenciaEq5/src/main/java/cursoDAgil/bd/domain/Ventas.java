package cursoDAgil.bd.domain;

import java.util.List;

public class Ventas {
	private Integer idVenta;
	private Integer clienteId;
	private Cliente cliente;
	private Double totalVenta;
	private String fecha;
	Ganancias ganancia;
	private List<DetalleVentas> detalleVentas;
	
	public Ventas(){
		setGanancia(new Ganancias());
		setCliente(new Cliente());
	}
	public void setCliente(Cliente cli) {
		this.cliente = cli;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setGanancia(Ganancias ganancia) {
		this.ganancia = ganancia;
	}
	public Ganancias getGanancia() {
		return ganancia;
	}
	public List<DetalleVentas> getDetalleVentas() {
		return detalleVentas;
	}
	public void setDetalleVentas(List<DetalleVentas> detalleVentas) {
		this.detalleVentas = detalleVentas;
	}
	public Integer getIdVenta() {
		return idVenta;
	}
	
	public void setIdVenta(Integer idVenta) {
		this.idVenta = idVenta;
	}
	
	public Integer getClienteId() {
		return clienteId;
	}
	 
	public void setClienteId(Integer clienteId) {
		this.clienteId = clienteId;
	}
	
	public Double getTotalVenta() {
		return totalVenta;
	}
	
	public void setTotalVenta(Double totalVenta) {
		this.totalVenta = totalVenta;
	}
	
	public String getFecha() {
		return fecha;
	}
	
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public boolean equals(Object object) {
		if(!(object instanceof Ventas)) {
			return false;
		}
		Ventas regVentas = (Ventas) object;
		return (this.idVenta == regVentas.idVenta);
	}

}
