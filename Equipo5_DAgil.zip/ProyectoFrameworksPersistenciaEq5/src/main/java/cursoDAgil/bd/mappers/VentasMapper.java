package cursoDAgil.bd.mappers;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Ventas;

public interface VentasMapper {
	List<Ventas> obtenerVentas();
	Integer nuevaVenta(Ventas venta);
	List<Ventas> obtenerVentasPorIdCliente(Map<String, Integer> mapCliente);
	Ventas obtenerUltimaVenta();
}
