package cursoDAgil.dao.marcas;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Marcas;

public interface MarcasDao {
	List<Marcas> obtenerMarcas();
	Integer nuevaMarca(Marcas marca);
	Marcas obtenerMarcaPorId(Map<String, Integer> mapMarcas);
	Integer modificarMarcaPorId(Marcas marca);
	Integer eliminarMarcaPorId(Map<String, Integer> mapMarcas);
	Marcas obtenerMarcaPorId(Integer idMarca);
	Integer eliminarMarcaPorId(Integer idMarca);
}