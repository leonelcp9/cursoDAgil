package cursoDAgil.dao.marcas;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import cursoDAgil.bd.domain.Marcas;
import cursoDAgil.bd.mappers.MarcasMapper;

@Named

public class MarcasDaoImp implements MarcasDao , Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3067887428564604517L;
	SqlSession sqlSession;

	@Autowired
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	@Override
	public Integer nuevaMarca(Marcas marcas) {
		try {
			MarcasMapper marcasMapper = sqlSession.getMapper(MarcasMapper.class);

			System.out.println("\nMarca creada con éxito");
			return marcasMapper.nuevaMarca(marcas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public Marcas obtenerMarcaPorId(Map<String, Integer> mapMarcas) {

		try {
			MarcasMapper marcasMapper = sqlSession.getMapper(MarcasMapper.class);
			return marcasMapper.obtenerMarcaPorId(mapMarcas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	@Override
	public Marcas obtenerMarcaPorId(Integer idMarca) {

		try {
			MarcasMapper marcasMapper = sqlSession.getMapper(MarcasMapper.class);
			return marcasMapper.obtenerMarcaPorId(idMarca);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public List<Marcas> obtenerMarcas() {
		List<Marcas> list = null;
		try {
			MarcasMapper marcasMapper = sqlSession.getMapper(MarcasMapper.class);
			list = marcasMapper.obtenerMarcas();
			for(Marcas m:list){
				System.out.println("\nidMarca: " + m.getIdMarca());
				System.out.println("Nombre: " + m.getNombreMarca());
				System.out.println("\n--------------------------------");
			}
			return list;
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public Integer modificarMarcaPorId(Marcas marca){
		try{
			MarcasMapper marcasMapper = sqlSession.getMapper(MarcasMapper.class);
			
			System.out.println("\nDatos de marca modificados con éxito");
			return marcasMapper.modificarMarcaPorId(marca);
		}catch (Exception e) {
			System.out.println("Error: " + e);
			
		}
			return null;
	}
	
	@Override
	public Integer eliminarMarcaPorId(Map<String, Integer> mapMarcas){
		try{
			MarcasMapper marcasMapper = sqlSession.getMapper(MarcasMapper.class);
			
			System.out.println("\nMarca eliminada con éxito");
			return marcasMapper.eliminarMarcaPorId(mapMarcas);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	@Override
	public Integer eliminarMarcaPorId(Integer idMarca){
		try{
			MarcasMapper marcasMapper = sqlSession.getMapper(MarcasMapper.class);
			
			System.out.println("\nMarca eliminada con éxito");
			return marcasMapper.eliminarMarcaPorId(idMarca);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
}