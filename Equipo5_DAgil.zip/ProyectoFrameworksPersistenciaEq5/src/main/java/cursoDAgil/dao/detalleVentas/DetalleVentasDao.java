package cursoDAgil.dao.detalleVentas;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.DetalleVentas;

public interface DetalleVentasDao {
	Integer nuevoDetalleVentas(DetalleVentas detalleVentas);
	List <DetalleVentas> obtenerDetallesVentasPorVenta(Map<String, Integer> mapVenta);
	List <DetalleVentas> obtenerDetallesVentas();

}
