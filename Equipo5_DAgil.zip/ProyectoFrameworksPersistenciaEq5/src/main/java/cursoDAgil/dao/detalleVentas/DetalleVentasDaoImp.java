package cursoDAgil.dao.detalleVentas;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import cursoDAgil.bd.domain.DetalleVentas;
import cursoDAgil.bd.domain.Marcas;
import cursoDAgil.bd.domain.Productos;
import cursoDAgil.bd.mappers.DetalleVentasMapper;
import cursoDAgil.bd.mappers.MarcasMapper;
import cursoDAgil.bd.mappers.ProductosMapper;
/**import cursoDAgil.dao.direccion.Direcciones;
import cursoDAgil.dao.direccion.DireccionesMapper;*/


@Named
public class DetalleVentasDaoImp implements DetalleVentasDao, Serializable{
	
	private static final long serialVersionUID = -3067887428564604517L;
	SqlSession sqlSession;

	@Autowired
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	@Override
	public Integer nuevoDetalleVentas(DetalleVentas detalleVentas) {
		try {
			DetalleVentasMapper detalleVentasMapper = sqlSession.getMapper(DetalleVentasMapper.class);

			System.out.println("DetalleVentas creada con éxito");
			return detalleVentasMapper.nuevoDetalleVentas(detalleVentas);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public List <DetalleVentas>  obtenerDetallesVentasPorVenta(Map<String, Integer> mapDetalleVentas) {
		List<DetalleVentas> list = null;
		try {
			DetalleVentasMapper detalleVentasMapper = sqlSession.getMapper(DetalleVentasMapper.class);
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);
			list = detalleVentasMapper.obtenerDetallesVentasPorVenta(mapDetalleVentas);
			Productos producto;
			Map<String, Integer> mapProducto = new HashMap<>();
			for(DetalleVentas dV:list){
				System.out.println("\nId venta: " + dV.getVentaId());
				System.out.println("\nId producto: " + dV.getProductoId());
				System.out.println("Nombre del producto: " + dV.getProductos().getNombre());
				System.out.println("Cantidad vendida: "+ dV.getCantidad());
				System.out.println("Precio: " + dV.getProductos().getPrecio());
				System.out.println("Precio Venta: " + dV.getProductos().getPrecioVta());
				System.out.println("Marca: " + dV.getProductos().getMarca().getNombreMarca());
				
				mapProducto.put("idProducto", dV.getProductoId());
				producto = productosMapper.obtenerProductoPorId(mapProducto);
				System.out.println("\nCantidad en inventario: " + producto.getCantidad());	
			}
			return list;
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public List<DetalleVentas> obtenerDetallesVentas() {
		List<DetalleVentas> list = null;
		try {
			DetalleVentasMapper detalleVentasMapper = sqlSession.getMapper(DetalleVentasMapper.class);
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);
			MarcasMapper marcasMapper = sqlSession.getMapper(MarcasMapper.class);
			list = detalleVentasMapper.obtenerDetallesVentas();
			Productos producto;
			Marcas marca;
			Map<String, Integer> mapProducto = new HashMap<>();
			Map<String, Integer> mapMarcas = new HashMap<>();
			for(DetalleVentas dV:list){
				System.out.println("\nId venta: " + dV.getVentaId());
				System.out.println("\nId producto: " + dV.getProductoId());
				mapProducto.put("idProducto", dV.getProductoId());
				producto = productosMapper.obtenerProductoPorId(mapProducto);
				System.out.println("Nombre del producto: " + producto.getNombre());
				System.out.println("Cantidad vendida: "+ dV.getCantidad());
				System.out.println("Precio: " + producto.getPrecio());
				System.out.println("Precio Venta: " + producto.getPrecioVta());
				mapMarcas.put("idMarca", producto.getMarcaId());
				marca = marcasMapper.obtenerMarcaPorId(mapMarcas);
				System.out.println("Marca: " + marca.getNombreMarca());
				System.out.println("Cantidad en inventario: " + producto.getCantidad());	
			}
			return list;
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
}