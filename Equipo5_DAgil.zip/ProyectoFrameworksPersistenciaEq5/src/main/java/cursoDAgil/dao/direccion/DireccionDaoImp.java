package cursoDAgil.dao.direccion;

import java.util.List;
import java.util.Map;

import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import cursoDAgil.bd.domain.Direccion;
import cursoDAgil.bd.mappers.DireccionMapper;

@Named
public class DireccionDaoImp implements DireccionDao {
	SqlSession sqlSession;
	@Autowired
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	@Override
	public Integer nuevaDireccion(Direccion direccion) {
		try {
			DireccionMapper direccionesMapper = sqlSession.getMapper(DireccionMapper.class);

			System.out.println("\nDirección creada con éxito");
			return direccionesMapper.nuevaDireccionCliente(direccion);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public Direccion obtenerDireccionPorId(Map<String, Integer> mapDireccion) {

		try {
			DireccionMapper direccionesMapper = sqlSession.getMapper(DireccionMapper.class);
			return direccionesMapper.obtenerDireccionPorId(mapDireccion);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public List<Direccion> obtenerDirecciones() {
		List<Direccion> list = null;
		try {
			DireccionMapper direccionesMapper = sqlSession.getMapper(DireccionMapper.class);
			list = direccionesMapper.obtenerDirecciones();
			for(Direccion d:list){
				System.out.println("\nidDireccion: " + d.getIdDireccion());
				System.out.println("Calle: " + d.getCalle());
				System.out.println("Numero: "+ d.getNumero());
				System.out.println("Colonia: "+ d.getColonia());
				System.out.println("Ciudad: "+ d.getCiudad());
				System.out.println("Estado: "+ d.getEstado());
				System.out.println("Pais: "+ d.getPais());
				System.out.println("Código Postal: "+ d.getCodigoPostal());
				System.out.println("\n-------------------------------");
			}
			return list;
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public Integer modificarDireccionPorId(Direccion direccion){
		try{
			DireccionMapper direccionMapper = sqlSession.getMapper(DireccionMapper.class);
			
			System.out.println("\nDatos de dirección modificados con éxito");
			return direccionMapper.modificarDireccionPorId(direccion);
		}catch (Exception e) {
			System.out.println("Error: " + e);
			
		}
			return null;
	}
	
	@Override
	public Integer eliminarDireccionPorId(Map<String, Integer> mapDireccion){
		try{
			DireccionMapper direccionMapper = sqlSession.getMapper(DireccionMapper.class);
			
			System.out.println("\nDirección eliminada con éxito");
			return direccionMapper.eliminarDireccionPorId(mapDireccion);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public Direccion obtenerDireccionPorId(Integer idDireccion) {
		try {
			DireccionMapper direccionesMapper = sqlSession.getMapper(DireccionMapper.class);
			return direccionesMapper.obtenerDireccionPorId(idDireccion);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public Integer eliminarDireccionPorId(Integer idDireccion){
		try{
			DireccionMapper direccionMapper = sqlSession.getMapper(DireccionMapper.class);
			
			System.out.println("\nDirección eliminada con éxito");
			return direccionMapper.eliminarDireccionPorId(idDireccion);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
}
