package cursoDAgil.dao.ganancias;

import java.util.List;
import java.util.Map;

import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import cursoDAgil.bd.domain.Ganancias;
import cursoDAgil.bd.mappers.GananciasMapper;

@Named
public class GananciasDaoImpl implements GananciasDao{
	SqlSession sqlSession;
	@Autowired
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	public List<Ganancias> obtenerGanancias() {
		List<Ganancias> list = null;
		try{
			GananciasMapper gananciasMapper = sqlSession.getMapper(GananciasMapper.class);
			list = gananciasMapper.obtenerGanancias();
			for(Ganancias m:list){
				System.out.println("idGanancia: " + m.getIdGanancia());
				System.out.println("ventaId: " + m.getVentaId());
				System.out.println("total Ganancia: " + m.getTotalGanancia());
				System.out.println("fecha: " + m.getFecha());
				System.out.println("");
			}
			return list;
		} catch (Exception e){
			System.out.println("Error: " + e);
		}
		return null;
	}

	public List<Ganancias> obtenerGananciaPorFecha(Map<String, String> mapGanancias) {
		List<Ganancias> list = null;
		try{
			GananciasMapper gananciasMapper = sqlSession.getMapper(GananciasMapper.class);
			list = gananciasMapper.obtenerGananciaPorFecha(mapGanancias);
			for(Ganancias m:list){
				System.out.println("idGanancia: " + m.getIdGanancia());
				System.out.println("ventaId: " + m.getVentaId());
				System.out.println("total Ganancia: " + m.getTotalGanancia());
				System.out.println("fecha: " + m.getFecha());
				System.out.println("");
			}
			return list;
		} catch (Exception e){
			System.out.println("Error: " + e);
		}
		return null;
	}

	public Integer nuevaGanancia(Ganancias ganancia) {
		try {
			GananciasMapper gananciasMapper = sqlSession.getMapper(GananciasMapper.class);

			System.out.println("ganancia creada con éxito");
			return gananciasMapper.nuevaGanancia(ganancia);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

}
