package cursoDAgil.dao.cliente;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import cursoDAgil.bd.domain.Cliente;
import cursoDAgil.bd.mappers.ClienteMapper;

@Named
public class ClienteDaoImp implements ClienteDao, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3067887428564604517L;
	
	SqlSession sqlSession;
	
	@Autowired
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	@Override
	public List<Cliente> obtenerClientes() {
		List<Cliente> list = null;
		try {
			ClienteMapper clienteMapper = sqlSession.getMapper(ClienteMapper.class);
			list = clienteMapper.obtenerClientes();
			for(Cliente c:list){
				System.out.println("\nId: " + c.getId());
				System.out.println("Nombre: " + c.getNombre());
				System.out.println("Apellido: "+ c.getApellido());
				System.out.println("Email: "+ c.getEmail());
				System.out.println("Sexo: "+ c.getSexo());
				System.out.println("Direccion: "+ c.getDireccion().getCalle() + " #" + c.getDireccion().getNumero() + ", " +c.getDireccion().getCiudad());
				System.out.println("\n-----------------------------------------------");
			}
			return list;
		} catch(Exception e){
			System.out.println("Error: " + e); 
		}
		return null;
	}
	
	@Override
	public List<Cliente> obtenerClientes_SinDireccion() {
		List<Cliente> list = null;
		try {
			ClienteMapper clienteMapper = sqlSession.getMapper(ClienteMapper.class);
			list = clienteMapper.obtenerClientes();
			for(Cliente c:list){
				System.out.println("\nId: " + c.getId());
				System.out.println("Nombre: " + c.getNombre());
				System.out.println("Apellido: "+ c.getApellido());
				System.out.println("Email: "+ c.getEmail());
				System.out.println("Sexo: "+ c.getSexo());
				System.out.println("\n-----------------------------------------------");
			}
			return list;
		} catch(Exception e){
			System.out.println("Error: " + e); 
		}
		return null;
	}
	
	
	@Override
	public Integer nuevoCliente(Cliente clientes) {
		try {
			ClienteMapper clientesMapper = sqlSession.getMapper(ClienteMapper.class);

			System.out.println("\nCliente creado con éxito");
			return clientesMapper.nuevoCliente(clientes);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public Cliente obtenerClientePorId(Map<String, Integer> mapClientes) {

		try {
			ClienteMapper clientesMapper = sqlSession.getMapper(ClienteMapper.class);
			return clientesMapper.obtenerClientePorId(mapClientes);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public Cliente obtenerClientePorId_SinDireccion(Map<String, Integer> mapClientes) {

		try {
			ClienteMapper clientesMapper = sqlSession.getMapper(ClienteMapper.class);
			return clientesMapper.obtenerClientePorId_SinDireccion(mapClientes);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public Integer modificarClientePorId(Cliente cliente){
		try{
			ClienteMapper clientesMapper = sqlSession.getMapper(ClienteMapper.class);
			
			System.out.println("\nDatos de cliente modificados con éxito");
			return clientesMapper.modificarClientePorId(cliente);
		}catch (Exception e) {
			System.out.println("Error: " + e);
			
		}
			return null;
	}
	
	@Override
	public Integer eliminarClientePorId(Map<String, Integer> mapClientes){
		try{
			ClienteMapper clientesMapper = sqlSession.getMapper(ClienteMapper.class);
			
			System.out.println("\nCliente eliminado con éxito");
			return clientesMapper.eliminarClientePorId(mapClientes);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public Cliente obtenerClientePorId(Integer idCliente) {

		try {
			ClienteMapper clientesMapper = sqlSession.getMapper(ClienteMapper.class);
			return clientesMapper.obtenerClientePorId(idCliente);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public Integer eliminarClientePorId(Integer idCliente){
		try{
			ClienteMapper clientesMapper = sqlSession.getMapper(ClienteMapper.class);
			
			System.out.println("\nCliente eliminado con éxito");
			return clientesMapper.eliminarClientePorId(idCliente);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
}
