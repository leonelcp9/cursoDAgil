package cursoDAgil.dao.cliente;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Cliente;

public interface ClienteDao {
	List<Cliente> obtenerClientes();
	Integer nuevoCliente(Cliente cliente);
	Cliente obtenerClientePorId(Map<String, Integer> mapCliente);
	Integer modificarClientePorId(Cliente cliente);
	Integer eliminarClientePorId(Map<String, Integer> mapCliente);
	Cliente obtenerClientePorId(Integer idCliente);
	Integer eliminarClientePorId(Integer idCliente);
	List<Cliente> obtenerClientes_SinDireccion();
	Cliente obtenerClientePorId_SinDireccion(Map<String, Integer> mapClientes);
}
