package cursoDAgil.dao.productos;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import cursoDAgil.bd.domain.Productos;
import cursoDAgil.bd.mappers.ProductosMapper;

@Named
public class ProductoDaoImp implements ProductoDao, Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3067887428564604517L;
	SqlSession sqlSession;

	@Autowired
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	@Override
	public Integer nuevoProducto(Productos productos) {
		try {
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);

			System.out.println("\nProducto creado con éxito");
			return productosMapper.nuevoProducto(productos);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public Productos obtenerProductoPorId(Map<String, Integer> mapProductos) {

		try {
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);
			return productosMapper.obtenerProductoPorId(mapProductos);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public Productos obtenerProductoPorId_SinMarca(Map<String, Integer> mapProductos) {

		try {
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);
			return productosMapper.obtenerProductoPorId_SinMarca(mapProductos);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public List<Productos> obtenerProductos() {
		List<Productos> list = null;
		try {
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);
			list = productosMapper.obtenerProductos();
			for(Productos p:list){
				System.out.println("\nidProducto: " + p.getIdProducto());
				System.out.println("Producto: " + p.getNombre());
				System.out.println("Precio: " + p.getPrecio());
				System.out.println("Precio Venta: " + p.getPrecioVta());
				System.out.println("Cantidad: " + p.getCantidad());
				System.out.println("Marca: " + p.getMarca().getNombreMarca());
				System.out.println("\n--------------------------------");
			}
			return list;
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}	
	
	@Override
	public List<Productos> obtenerProductos_SinMarca() {
		List<Productos> list = null;
		try {
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);
			list = productosMapper.obtenerProductos_SinMarca();
			for(Productos p:list){
				System.out.println("\nidProducto: " + p.getIdProducto());
				System.out.println("Producto: " + p.getNombre());
				System.out.println("Precio: " + p.getPrecio());
				System.out.println("Precio Venta: " + p.getPrecioVta());
				System.out.println("Cantidad: " + p.getCantidad());
				System.out.println("\n--------------------------------");
			}
			return list;
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}	
		
	@Override
	public Integer modificarProductoPorId(Productos productos){
		try{
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);
			
			System.out.println("\nDatos de producto modificados con éxito");
			return productosMapper.modificarProductoPorId(productos);
		}catch (Exception e) {
			System.out.println("Error: " + e);
			
		}
			return null;
	}
	
	@Override
	public Integer eliminarProductoPorId(Map<String, Integer> mapProductos){
		try{
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);
			
			System.out.println("\nProducto eliminado con éxito");
			return productosMapper.eliminarProductoPorId(mapProductos);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public Productos obtenerProductoPorId(Integer idProducto) {

		try {
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);
			return productosMapper.obtenerProductoPorId(idProducto);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public Integer eliminarProductoPorId(Integer idProducto){
		try{
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);
			
			System.out.println("\nProducto eliminado con éxito");
			return productosMapper.eliminarProductoPorId(idProducto);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
}

