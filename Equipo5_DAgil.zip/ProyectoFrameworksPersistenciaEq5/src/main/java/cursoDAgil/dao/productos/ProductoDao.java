package cursoDAgil.dao.productos;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Productos;

public interface ProductoDao{
	List<Productos> obtenerProductos();
	Integer nuevoProducto(Productos producto);
	Productos obtenerProductoPorId(Map<String, Integer> mapProductos);
	Integer modificarProductoPorId(Productos producto);
	Integer eliminarProductoPorId(Map<String, Integer> mapProductos);
	
	List<Productos> obtenerProductos_SinMarca();
	Productos obtenerProductoPorId_SinMarca(Map<String, Integer> mapProducto);
	
	Productos obtenerProductoPorId(Integer idProducto);
	Integer eliminarProductoPorId(Integer idProducto);
}