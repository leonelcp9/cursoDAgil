package cursoDAgil.dao.ventas;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import cursoDAgil.bd.domain.DetalleVentas;
import cursoDAgil.bd.domain.Productos;
import cursoDAgil.bd.domain.Ventas;
import cursoDAgil.bd.mappers.ProductosMapper;
import cursoDAgil.bd.mappers.VentasMapper;
import cursoDAgil.bd.mappers.DetalleVentasMapper;
import cursoDAgil.bd.mappers.GananciasMapper;

@Named
public class VentasDaoImp implements VentasDao, Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3514598916206774039L;
	SqlSession sqlSession;

	@Autowired
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}


	public Integer nuevaVenta(Ventas venta) {
		try {
			VentasMapper ventasMapper = sqlSession.getMapper(VentasMapper.class);
			int i = ventasMapper.nuevaVenta(venta);
			int idVenta=ventasMapper.obtenerUltimaVenta().getIdVenta();
			DetalleVentasMapper detalleVentaMapper = sqlSession.getMapper(DetalleVentasMapper.class);
			//Actualizar inventario 
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);
			Productos productoNuevo;
			List<DetalleVentas> dvLista=venta.getDetalleVentas();
			
			double ganancias=0;
			
			for(DetalleVentas detalleVentas: dvLista){
				productoNuevo = detalleVentas.getProductos();
				productoNuevo.setCantidad(detalleVentas.getProductos().getCantidad() - detalleVentas.getCantidad());
				productosMapper.modificarProductoPorId(productoNuevo);
				ganancias+= (productoNuevo.getPrecioVta() - productoNuevo.getPrecio())*detalleVentas.getCantidad();
				
				//Registrar detalleVentas
				detalleVentas.setVentaId(idVenta);
				detalleVentaMapper.nuevoDetalleVentas(detalleVentas);
			}
			
			//Crear ganancia
			venta.getGanancia().setFecha(venta.getFecha());
			venta.getGanancia().setTotalGanancia(ganancias);
			venta.getGanancia().setVentaId(idVenta);	
			

			
			
			
			//registrar
			
			System.out.println("Venta y ganancia creado con éxito");
			
			
			GananciasMapper gananciaMapper = sqlSession.getMapper(GananciasMapper.class);
			gananciaMapper.nuevaGanancia(venta.getGanancia());
			return i;
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}


	public List<Ventas> obtenerVentasPorIdCliente(Map<String, Integer> mapCliente) {

		try {
			VentasMapper ventasMapper = sqlSession.getMapper(VentasMapper.class);

			return ventasMapper.obtenerVentasPorIdCliente(mapCliente);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}


	public List<Ventas> obtenerVentas() {
		try {
			VentasMapper ventasMapper = sqlSession.getMapper(VentasMapper.class);

			return ventasMapper.obtenerVentas();
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	

}