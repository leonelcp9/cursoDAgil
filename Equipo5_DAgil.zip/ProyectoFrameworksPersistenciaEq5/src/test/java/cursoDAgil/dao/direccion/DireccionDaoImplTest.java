package cursoDAgil.dao.direccion;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Direccion;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/applicationContext.xml"})
public class DireccionDaoImplTest {
	
	@Inject
	DireccionDao direccionDao;
	
	@Ignore
	public void consultarDireccionPorId(){
		Direccion direccion = new Direccion();
		Map<String, Integer> mapDireccion = new HashMap<>();
		mapDireccion.put("idDireccion", 1);
		System.out.println("\n\nTest consultar direccion por id");
		try{
			direccion = direccionDao.obtenerDireccionPorId(mapDireccion);
			assertNotNull(direccion);
			System.out.println("\nidDireccion: " + direccion.getIdDireccion());
			System.out.println("Calle: " + direccion.getCalle());
			System.out.println("Numero: "+ direccion.getNumero());
			System.out.println("Colonia: "+ direccion.getColonia());
			System.out.println("Ciudad: "+ direccion.getCiudad());
			System.out.println("Estado: "+ direccion.getEstado());
			System.out.println("Pais: "+ direccion.getPais());
			System.out.println("Código Postal: "+ direccion.getCodigoPostal() + "\n");
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Ignore 
	public void consultarDireccionPorIdInteger(){
		Direccion direccion = new Direccion();
		System.out.println("\n\nTest consultar direccion por id");
		try{
			direccion = direccionDao.obtenerDireccionPorId(1);
			assertNotNull(direccion);
			System.out.println("\nidDireccion: " + direccion.getIdDireccion());
			System.out.println("Calle: " + direccion.getCalle());
			System.out.println("Numero: "+ direccion.getNumero());
			System.out.println("Colonia: "+ direccion.getColonia());
			System.out.println("Ciudad: "+ direccion.getCiudad());
			System.out.println("Estado: "+ direccion.getEstado());
			System.out.println("Pais: "+ direccion.getPais());
			System.out.println("Código Postal: "+ direccion.getCodigoPostal() + "\n");
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Test
	public void pruebaConsultarTodo(){
		int reg;
		System.out.println("\n\nTest consultar todas las direcciones");
		System.out.println("\nListado de direcciones:");
		try{
			List<Direccion> lista = direccionDao.obtenerDirecciones();
			reg = lista.size();
			assertEquals(lista.size(), reg);
			System.out.println("\n\nRegistro en la tabla: " + reg + " direcciones\n");
		}catch(Exception ex){
			System.out.println("error" + ex);
		}
	}
	
	@Ignore
	public void nuevaDireccion(){
		Direccion direccion = new Direccion();
		
		System.out.println("\n\nTest nuevo registro de direccion\n");
		try{
			direccion.setCalle("5 de febrero");
			direccion.setNumero(15);
			direccion.setColonia("Centro");
			direccion.setCiudad("SJC");
			direccion.setEstado("BCS");
			direccion.setPais("Mexico");
			direccion.setCodigoPostal(26485);
			direccionDao.nuevaDireccion(direccion);
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Ignore		
	public void modificarDireccion(){
		Direccion direccion = new Direccion();
		System.out.println("\n\nTest modificar Direccion\n");
		try{
			direccion.setIdDireccion(1);
			direccion.setCalle("Margarito Sandez Villarino");
			direccion.setNumero(89);
			direccion.setColonia("El Zacatal");
			direccion.setCiudad("San Jose del Cabo");
			direccion.setEstado("BCS");
			direccion.setPais("Mex");
			direccion.setCodigoPostal(23000);
			direccionDao.modificarDireccionPorId(direccion);
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Ignore			
	public void eliminarDireccion(){
		Direccion direccion = new Direccion();
		Map<String, Integer> mapDireccion = new HashMap<>();
		mapDireccion.put("idDireccion", 2);
		System.out.println("\n\nTest eliminar direccion\n");
		try{
			direccionDao.eliminarDireccionPorId(mapDireccion);
			assertNotNull(direccion);
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
}
