package cursoDAgil.dao.productos;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Productos;
import cursoDAgil.dao.productos.ProductoDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/applicationContext.xml"})

public class ProductosDaoImplTest {
	
	@Inject
	 ProductoDao productoDao;
	
	@Ignore
	public void nuevoProducto(){
		Productos producto = new Productos();
		System.out.println("\n\nTest nuevo registro de Producto\n");
		try{
			producto.setNombre("Blusa");
			producto.setPrecio(1000);
			producto.setPrecioVta(1050);
			producto.setCantidad(4);
			producto.setMarcaId(1);
			productoDao.nuevoProducto(producto);
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	
	@Ignore		
	public void modificarProducto(){
		Productos producto = new Productos();
		System.out.println("\n\nTest modificar Producto\n");
		try{
			producto.setIdProducto(1);
			producto.setNombre("Tenis Air Max");
			producto.setPrecio(2100);
			producto.setPrecioVta(2450);
			producto.setCantidad(20);
			producto.setMarcaId(5);
			productoDao.modificarProductoPorId(producto);
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	
	@Test
	public void pruebaConsultarTodo(){
		int reg;
		System.out.println("\n\nTest consultar todos los productos con marca\n");
		try{
			List<Productos> lista = productoDao.obtenerProductos();
			reg = lista.size();
			assertEquals(lista.size(), reg);
			System.out.println("\n\nRegistro en la tabla: " + reg + " productos");
		}catch(Exception ex){
			System.out.println("error" + ex);
		}
	}
	
	@Test
	public void pruebaConsultarTodoSinMarca(){
		int reg;
		System.out.println("\n\nTest consultar todos los productos sin marca\n");
		try{
			List<Productos> lista = productoDao.obtenerProductos_SinMarca();
			reg = lista.size();
			assertEquals(lista.size(), reg);
			System.out.println("\n\nRegistro en la tabla: " + reg + " productos");
		}catch(Exception ex){
			System.out.println("error" + ex);
		}
	}
	
	
	@Ignore			
	public void consultarProductoPorId(){
		Productos producto = new Productos();
		Map<String, Integer> mapProducto = new HashMap<>();
		mapProducto.put("idProducto", 1);
		System.out.println("\n\nTest consultar producto por id con marca\n");
		try{
			producto = productoDao.obtenerProductoPorId(mapProducto);
			assertNotNull(producto);
			System.out.println("idProducto: " + producto.getIdProducto());
			System.out.println("Producto: " + producto.getNombre());
			System.out.println("Precio: " + producto.getPrecio());
			System.out.println("Nombre: " + producto.getPrecioVta());
			System.out.println("Cantidad: " + producto.getCantidad());
			System.out.println("Marca: " + producto.getMarca().getNombreMarca() + "\n");
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Ignore		
	public void consultarProductoPorIdSinMarca(){
		Productos producto = new Productos();
		Map<String, Integer> mapProducto = new HashMap<>();
		mapProducto.put("idProducto", 1);
		System.out.println("\n\nTest consultar producto por id sin marca\n");
		try{
			producto = productoDao.obtenerProductoPorId_SinMarca(mapProducto);
			assertNotNull(producto);
			System.out.println("idProducto: " + producto.getIdProducto());
			System.out.println("Producto: " + producto.getNombre());
			System.out.println("Precio: " + producto.getPrecio());
			System.out.println("Nombre: " + producto.getPrecioVta());
			System.out.println("Cantidad: " + producto.getCantidad());
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Ignore
	public void eliminarProducto(){
		Productos producto = new Productos();
		Map<String, Integer> mapProducto = new HashMap<>();
		mapProducto.put("idProducto", 2);
		System.out.println("\n\nTest eliminar de Producto\n");
		try{
			productoDao.eliminarProductoPorId(mapProducto);
			assertNotNull(producto);
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
}
