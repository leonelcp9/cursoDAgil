package cursoDAgil.dao.marcas;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Marcas;
import cursoDAgil.dao.marcas.MarcasDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/applicationContext.xml"})

public class MarcasDaoImplTest {
	@Inject
	 MarcasDao marcasDao; 
	
	@Ignore
	public void nuevaMarca(){
		Marcas marca = new Marcas();
		System.out.println("\n\nTest nuevo registro de marca\n");
		try{
			marca.setNombreMarca("Nike");
			marcasDao.nuevaMarca(marca);
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Ignore
	public void consultarMarcaPorId(){
		Marcas marca = new Marcas();
		Map<String, Integer> mapMarca = new HashMap<>();
		mapMarca.put("idMarca", 1);
		System.out.println("\n\nTest consultar marca por id\n");
		try{
			marca = marcasDao.obtenerMarcaPorId(mapMarca);
			assertNotNull(marca);
			System.out.println("id: " + marca.getIdMarca());
			System.out.println("Nombre: " + marca.getNombreMarca());
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Test
	public void pruebaConsultarTodo(){
		int reg;
		System.out.println("\n\nTest consultar todas las marcas\n");
		try{
			List<Marcas> lista = marcasDao.obtenerMarcas();
			reg = lista.size();
			assertEquals(lista.size(), reg);
			System.out.println("\nRegistro en la tabla: " + reg + " marcas");
		}catch(Exception ex){
			System.out.println("error" + ex);
		}
	}
	
	@Ignore
	public void eliminarMarca(){
		Marcas marca = new Marcas();
		Map<String, Integer> mapMarca = new HashMap<>();
		mapMarca.put("idMarca", 2);
		System.out.println("\n\nTest eliminar marca\n");
		try{
			marcasDao.eliminarMarcaPorId(mapMarca);
			assertNotNull(marca);
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	@Ignore
	public void modificarMarca(){
		Marcas marca = new Marcas();
		System.out.println("\n\nTest modificar marca\n");
		try{
			marca.setIdMarca(1);
			marca.setNombreMarca("Adidas");
			marcasDao.modificarMarcaPorId(marca);
			assertNotNull(marca);
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
}
