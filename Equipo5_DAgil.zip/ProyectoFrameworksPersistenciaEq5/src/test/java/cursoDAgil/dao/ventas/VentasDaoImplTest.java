package cursoDAgil.dao.ventas;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.DetalleVentas;
import cursoDAgil.bd.domain.Ganancias;
import cursoDAgil.bd.domain.Productos;
import cursoDAgil.bd.domain.Ventas;
import cursoDAgil.bd.mappers.ProductosMapper;
import cursoDAgil.dao.productos.ProductoDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/applicationContext.xml"})
public class VentasDaoImplTest {
	SqlSession sqlSession;

	@Autowired
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}	

	@Inject
	VentasDao ventasDao;
	@Inject
	ProductoDao productoDao;
	
	@Test
	public void pruebaConsultarTodo(){
		System.out.println("\n\nTest consular todos las ventas");
		try{
			List<Ventas> lista = ventasDao.obtenerVentas();
			int reg = lista.size();
			assertEquals(lista.size(),reg);
			System.out.println("\n\n\nRegistro en la tabla: " + reg + " ventas");
			for(Ventas v: lista) {
				System.out.println("\nEsta venta tiene " + v.getDetalleVentas().size() + " detalle ventas");
			}
		}catch(Exception ex){
			System.out.println("error" + ex);
		}
	}
	
	@Ignore
	public void obtenerVentasPorIdCliente(){
		Map<String, Integer> mapCliente = new HashMap<>();
		mapCliente.put("clienteId", 1);
		System.out.println("\n\nTest consultar ventas por id cliente\n");
		try{			
			List<Ventas> lista = ventasDao.obtenerVentasPorIdCliente(mapCliente);
			int reg = lista.size();
			assertEquals(lista.size(),reg);
			System.out.println("\n\n\nRegistro en la tabla: " + reg + " ventas");	
		}catch(Exception e){
			System.out.println("Error" + e);
		}
	}
	
	
	@Ignore
	public void newVenta(){
		Ventas venta = new Ventas();
		Ganancias ganancia = new Ganancias();
		List<DetalleVentas> detalleVentas = new ArrayList<DetalleVentas>();
		System.out.println("Test nuevo registro de Ventas");
		try{
			//info venta
			venta.setClienteId(1);
			venta.setTotalVenta(123.45);
			venta.setFecha("2021-05-31");
			
			
			
			//Test
			List<Productos> productosLista = new ArrayList<Productos>();
			ProductosMapper productoMapper = sqlSession.getMapper(ProductosMapper.class);
			Map<String, Integer> mapProducto2 = new HashMap<String, Integer>();
			mapProducto2.put("idProducto", 1);
			Map<String, Integer> mapProducto1 = new HashMap<String, Integer>();
			mapProducto1.put("idProducto", 2);
			Productos p1 = productoMapper.obtenerProductoPorId(mapProducto2);
			productosLista.add(p1);
			Productos p2 = productoMapper.obtenerProductoPorId(mapProducto1);
			
			productosLista.add(p2);
			//Carrito
			for(Productos p : productosLista) {
				DetalleVentas detalleVenta = new DetalleVentas();
				detalleVenta.setCantidad(1);
				detalleVenta.setProductoId(p.getIdProducto());

	
				detalleVenta.setProductos(p);
				//detalleVenta.setProductos(productoDao.obtenerProductoPorId(mapProducto));
				
				//Agregar todos los detallesVentas
				detalleVentas.add(detalleVenta);
			}
			//Fin carrito
			

			
			venta.setDetalleVentas(detalleVentas);
			venta.setGanancia(ganancia);
			venta.setIdVenta(1);
			System.out.println("Venta registrada con éxito");
			ventasDao.nuevaVenta(venta);
		}
		catch(Exception e){
			System.out.println("Error: " + e);
		}
	}
}