package cursoDAgil.dao.ganancias;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Ganancias;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/applicationContext.xml"})
public class GananciasDaoImplTest {
	
	@Inject
	GananciasDao gananciasDao;
	
	@Ignore
	public void consultarGananciasPorFecha(){
		Map<String,String> mapGanancias = new HashMap<String, String>();
		mapGanancias.put("fecha", "2021-05-31");
		int reg;
		System.out.println("\n\nTest consultar ganancias por fecha");
		try{
			List<Ganancias> lista = gananciasDao.obtenerGananciaPorFecha(mapGanancias);
			reg = lista.size();
			assertEquals(lista.size(), reg);
			System.out.println("\nRegistro en la tabla: " + reg);
		} catch(Exception e){
			System.out.println("Error" + e);
		}
		
	}
	
	@Test
	public void pruebaConsultarTodo(){
		int reg;
		System.out.println("\n\nTest consultar todas las ganancias");
		try{
			List<Ganancias> lista = gananciasDao.obtenerGanancias();
			reg = lista.size();
			assertEquals(lista.size(), reg);
			System.out.println("\nRegistro en la tabla: " + reg);
		}catch(Exception ex){
			System.out.println("error" + ex);
		}
	}
	
	@Ignore
	public void crearGanancia(){
		Ganancias ganancia = new Ganancias();
		System.out.println("\n\nTest crear ganancia");
		try{
			ganancia.setFecha("13-05-20");
			ganancia.setTotalGanancia(288.00);
			ganancia.setVentaId(1);
			gananciasDao.nuevaGanancia(ganancia);
		}catch(Exception ex){
			System.out.println("error" + ex);
		}
	}
}
