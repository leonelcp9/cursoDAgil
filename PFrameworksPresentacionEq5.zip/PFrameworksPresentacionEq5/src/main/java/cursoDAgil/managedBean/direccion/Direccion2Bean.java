/*****************************************/
/* Capa Presentación: Equipo5            */
/* Autor: Martínez Guzman Erika Michelle */
/* 31/05/2021                            */
/*****************************************/

package cursoDAgil.managedBean.direccion;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.CellEditEvent;
import org.primefaces.event.RowEditEvent;

import cursoDAgil.bd.domain.Cliente;
import cursoDAgil.bd.domain.Direccion;
import cursoDAgil.managedBean.cliente.ClienteDireccion2Bean;
import cursoDAgil.service.cliente.ClienteService;
import cursoDAgil.service.direccion.DireccionService;

@Named
@ViewScoped
public class Direccion2Bean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5050465738679619261L;
	@Inject
	DireccionService direccionService;
	
	@Inject 
	ClienteService clienteService;
	@Inject
	ClienteDireccion2Bean clienteDireccion2Bean;
	
	private List<Direccion> listaDireccion;
	private Direccion direccion;
	
	private List<Cliente> listaCliente;
	
	@PostConstruct
	public void init(){
		if(listaDireccion == null)
			listaDireccion = new ArrayList<Direccion>();
		if(direccion == null)
			direccion = new Direccion();
		setListaDireccion(direccionService.obtenerDirecciones());
	}

	//metodo registrar una nueva marca
	public void registrar(){	
		//invocar al servicio
		direccionService.nuevaDireccion(getDireccion());
		setDireccion(new Direccion());
		// se actualiza los valores de la tabla
		setListaDireccion(direccionService.obtenerDirecciones());
		clienteDireccion2Bean.setlistaCliente(clienteService.obtenerClientes());
		getListaDireccion();
		FacesContext.getCurrentInstance().addMessage("aqui falla null", new FacesMessage("Registro exitoso!"));
	}
	
	public void onRowEdit(RowEditEvent event) {
		Direccion dir = ((Direccion) event.getObject());

		System.out.println("Verificando edición");
		if (dir.getCalle()=="" || dir.getNumero()==0 || dir.getColonia()=="" || dir.getCiudad()=="" || 
		dir.getEstado()=="" || dir.getPais()=="" || dir.getCodigoPostal()==0 ) {
			FacesMessage msg = new FacesMessage("¡Falló la edición!, ha dejado algun campo vacío. Por favor llene "
					+ "todos los campos o al reiniciar el sistema su dirección aparecerá como la última edición "
					+ "guardada.", dir.getIdDireccion().toString());
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}else{
			direccionService.modificarDireccionPorId(dir);
			clienteDireccion2Bean.setlistaCliente(clienteService.obtenerClientes());
			FacesMessage msg = new FacesMessage("Dirección editada", dir.getIdDireccion().toString());
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
	}

	public void onRowCancel(RowEditEvent event) {
		FacesMessage msg = new FacesMessage("Edición cancelada", ((Direccion) event.getObject()).getIdDireccion().toString());
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}
	
	public void onCellEdit(CellEditEvent event) {
		Object oldValue = event.getOldValue();
		Object newValue = event.getNewValue();
		System.out.println("verifica: " + newValue);
		if (newValue != null && !newValue.equals(oldValue)) {
			clienteDireccion2Bean.setlistaCliente(clienteService.obtenerClientes());
			FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Dirección modificada", "Antes: " + oldValue + ", Ahora: " + newValue);
			FacesContext.getCurrentInstance().addMessage(null, msg);
			
		}
	}
	
	//función para eliminar 
		public void eliminar(){
			listaDireccion = getListaDireccion();
			boolean bandera=false;
			boolean bandera2=false;
			
			for(Direccion p: listaDireccion){
				//System.out.printf("productos: " + p.getNombreMarca() + " valor: " + p.getSelected() + "\n" );
				if(p.getSelected()){
					bandera2=false;
					listaCliente = clienteService.obtenerClientes();
					for(Cliente cli: listaCliente){
						if(cli.getIddireccion()== p.getIdDireccion() && bandera2==false){
							FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("La direccion "
									+ "con id " + p.getIdDireccion() + " tiene un cliente asociado, no se puede eliminar"));
							bandera2=true;
						}
					}
					if(bandera2==false){
						direccionService.eliminarDireccionPorId(p.getIdDireccion());
						setListaDireccion(direccionService.obtenerDirecciones());
						bandera=true;
					}
				}
			}
			if(bandera){
				getListaDireccion();
				clienteDireccion2Bean.setlistaCliente(clienteService.obtenerClientes());
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Dirección eliminada"));
			}
		}
	
	//getters and setters
	public List<Direccion> getListaDireccion(){
		return listaDireccion;
	}
	
	public void setListaDireccion(List<Direccion> listaDireccion){
		this.listaDireccion = listaDireccion;
	}
	
	public Direccion getDireccion(){
		return direccion;
	}
	
	public void setDireccion(Direccion direccion){
		this.direccion = direccion;
	}
}
