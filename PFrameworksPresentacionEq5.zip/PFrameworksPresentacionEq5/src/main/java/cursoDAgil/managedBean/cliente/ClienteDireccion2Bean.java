/*****************************************/
/* Capa Presentación: Equipo5            */
/* Autor: Ramírez González Metztli       */
/* 03/06/2021                            */
/*****************************************/

package cursoDAgil.managedBean.cliente;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.CellEditEvent;
import org.primefaces.event.RowEditEvent;

import cursoDAgil.bd.domain.Cliente;
import cursoDAgil.managedBean.ventas.VentasBean;
import cursoDAgil.service.cliente.ClienteService;
import cursoDAgil.service.ventas.VentasService;

@Named
@ViewScoped
public class ClienteDireccion2Bean implements Serializable {
	/**
	*
	*/
	private static final long serialVersionUID = 6472377493921731094L;
	@Inject
	ClienteService clienteService;
	@Inject
	VentasService ventasService;
	
	@Inject
	VentasBean ventasBean;
	
	private List<Cliente> listaCliente;
	private Cliente cliente;
	

	@PostConstruct
	public void init() {
		if (listaCliente == null)
			listaCliente = new ArrayList<Cliente>();
		if (cliente == null) {
			cliente = new Cliente();
			cliente.setDireccion(null);
		}
		// se invoca el metodo del servicio para obtener los clientes con su dirección
		setlistaCliente(clienteService.obtenerClientes());
		// setlistaCliente(clienteService.findAllClientes());
	}

	// metodo que registra nuevo cliente
	public void registrar() {
		//invocar al servicio
		clienteService.nuevoCliente(getCliente());
		setCliente(new Cliente());
		// se actualiza los valores de la tabla
		setlistaCliente(clienteService.obtenerClientes());
		getlistaCliente();
		ventasBean.setlistaClientes(clienteService.obtenerClientes());
		FacesContext.getCurrentInstance().addMessage("aqui falla null", new FacesMessage("Registro exitoso!"));
	}

	public void onRowEdit(RowEditEvent event) {
		Cliente cli = ((Cliente) event.getObject());
		
		System.out.println("Verificando edición");
		
		if(cli.getNombre()=="" || cli.getApellido()=="" || cli.getEmail()=="" || cli.getSexo()==""){
			FacesMessage msg = new FacesMessage("¡Falló la edición!, ha dejado algun campo vacío. Por favor llene "
					+ "todos los campos o al reiniciar el sistema su dirección aparecerá como la última edición "
					+ "guardada.", cli.getId().toString());
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}else{
			cli.setDireccion(cliente.getDireccion());
			clienteService.modificarClientePorId(cli);
			ventasBean.setlistaClientes(clienteService.obtenerClientes());
			ventasBean.setlistaVentas(ventasService.obtenerVentas());
			FacesMessage msg = new FacesMessage("Cliente editado", cli.getId().toString());
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
	}

	public void onRowCancel(RowEditEvent event) {
		FacesMessage msg = new FacesMessage("Edición cancelada", ((Cliente) event.getObject()).getId().toString());

		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void onCellEdit(CellEditEvent event) {
		Object oldValue = event.getOldValue();
		Object newValue = event.getNewValue();
		System.out.println("verifica: " + newValue);
		if (newValue != null && !newValue.equals(oldValue)) {
			FacesMessage msg = new

			FacesMessage(FacesMessage.SEVERITY_INFO, "Cliente modificado", "Antes: " + oldValue + ", Ahora: " + newValue);
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
	}
	
	public void eliminar(){
		listaCliente = getlistaCliente();
		boolean bandera=false;
		
		for(Cliente p: listaCliente){
			//System.out.printf("productos: " + p.getNombreMarca() + " valor: " + p.getSelected() + "\n" );
			if(p.getSelected()){
				if(ventasService.obtenerVentasPorIdCliente(p.getId()).size()>0){
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("El cliente "
							+ "con id " + p.getId() + " tiene una venta asociada, no se puede eliminar"));
				}else{
					clienteService.eliminarClientePorId(p.getId());
					setlistaCliente(clienteService.obtenerClientes());
					bandera=true;
				}
			}
		}
		if(bandera){
			getlistaCliente();
			ventasBean.setlistaClientes(clienteService.obtenerClientes());
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Cliente eliminado"));
		}
	}
	
	// setters y getters
	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public List<Cliente> getlistaCliente() {
		return listaCliente;
	}

	public void setlistaCliente(List<Cliente> listaCliente) {
		this.listaCliente = listaCliente;
	}
}