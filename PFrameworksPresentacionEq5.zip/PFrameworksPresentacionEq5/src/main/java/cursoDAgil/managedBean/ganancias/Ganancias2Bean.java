/*****************************************/
/* Capa Presentación: Equipo5            */
/* Autor: Payán Rosales Carlos Antonio   */
/* 04/06/2021                            */
/*****************************************/

package cursoDAgil.managedBean.ganancias;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import javax.faces.bean.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import cursoDAgil.bd.domain.Ganancias;
import cursoDAgil.service.ganancias.GananciasService;

@Named
@ViewScoped
public class Ganancias2Bean implements Serializable {

	private static final long serialVersionUID = 5050465738679619261L;
	
	@Inject
	GananciasService gananciasService;
	
	private List<Ganancias> listaGanancias;
	private Ganancias ganancia;
	
	@PostConstruct
	public void init(){
		if(listaGanancias == null){
			listaGanancias = new ArrayList<Ganancias>();
		}
		if(ganancia == null){
			ganancia = new Ganancias();
		}
		setListaGanancias(gananciasService.obtenerGanancias());
	}

	public List<Ganancias> getListaGanancias() {
		return listaGanancias;
	}

	public void setListaGanancias(List<Ganancias> listaGanancias) {
		this.listaGanancias = listaGanancias;
	}
	
	public Ganancias getGanancias(){
		return ganancia;
	}

	public void setGanancias(Ganancias ganancia) {
		this.ganancia = ganancia;
	}
}
