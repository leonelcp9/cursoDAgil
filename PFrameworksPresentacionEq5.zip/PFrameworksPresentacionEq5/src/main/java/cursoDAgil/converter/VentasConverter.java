/*****************************************/
/* Capa Presentación: Equipo5            */
/* Autor: Vásquez Tejada Victor Antonio  */
/* 31/05/2021                            */
/*****************************************/

package cursoDAgil.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;

import cursoDAgil.bd.domain.Ventas;
import cursoDAgil.service.ventas.VentasService;

@Named
public class VentasConverter implements Converter {
	@Inject
	VentasService ventasService;

	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		if (value != null && (value.trim().length() > 0)) {
			try {
				
				return ventasService.obtenerVentasPorIdCliente(Integer.parseInt(value));

			} catch (NumberFormatException e) {
				return null;
			}
		} else {
			return null;
		}
	}

	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (((value != null) && ((Ventas) value).getClienteId() != null)) {
			return ((Ventas) value).getClienteId().toString();
		} else {
			return null;
		}
	}
}