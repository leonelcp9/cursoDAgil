/*****************************************/
/* Proyecto presentacion Equipo5         */
/* Autor: Hernandez Santos Marco Antonio */
/* 29/05/2021                            */
/*****************************************/

package cursoDAgil.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;

import cursoDAgil.bd.domain.Productos;
import cursoDAgil.service.productos.ProductoService;

@Named
public class ProductosConverter implements Converter  {

		@Inject
		ProductoService productoService;

		public Object getAsObject(FacesContext context, UIComponent component, String value) {

			if (value != null && (value.trim().length() > 0)) {
				try {
					return productoService.obtenerProductoPorId(Integer.parseInt(value));

				} catch (NumberFormatException e) {
					return null;
				}
			} else {
				return null;
			}
		}

		public String getAsString(FacesContext context, UIComponent component, Object value) {

			if (((value != null) && ((Productos) value).getIdProducto()

			!= null)) {

				return ((Productos) value).getIdProducto().toString();
			} else {
				return null;
			}
		}

	
}
