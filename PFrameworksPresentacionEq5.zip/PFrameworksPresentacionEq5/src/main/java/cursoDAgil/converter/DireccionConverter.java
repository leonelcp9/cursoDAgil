/*****************************************/
/* Capa Presentación: Equipo5            */
/* Autor: Martínez Guzman Erika Michelle */
/* 31/05/2021                            */
/*****************************************/

package cursoDAgil.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;

import cursoDAgil.bd.domain.Direccion;
import cursoDAgil.service.direccion.DireccionService;

@Named
public class DireccionConverter implements Converter {
	@Inject
	DireccionService direccionService;

	public Object getAsObject(FacesContext context, UIComponent component, String value) {

		if (value != null && (value.trim().length() > 0)) {
			try {
				return

				direccionService.obtenerDireccionPorId(Integer.parseInt(value));

			} catch (NumberFormatException e) {
				return null;
			}
		} else {
			return null;
		}
	}

	public String getAsString(FacesContext context, UIComponent component, Object value) {

		if (((value != null) && ((Direccion) value).getIdDireccion()

		!= null)) {

			return ((Direccion) value).getIdDireccion().toString();
		} else {
			return null;
		}
	}

}